import {DermatologistHomepageComponent} from "@/components/dermatologist-homepage";

export default function Home() {
    return (
        <DermatologistHomepageComponent/>
    );
}
